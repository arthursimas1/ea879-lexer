// Exemplo 6:

int main() {
    int a, b, c;
    int perimeter;
    read(a);
    read(b);
    read(c);
    /*
        Calculate the perimeter of the triangle
    */
    perimeter = a + b + c;
    print("The perimeter of the triangle is: ", perimeter);
    print();
    return 0;
}
"multiline string
error"
