int main()
{
	int a = 2;
	// print(a);
	a=a+1;
	/* int b = 4;
	int c = 3 */
	
	int b = 8;
	int c = 3;
	int d = c*(a+b;

	/* print(a);
	a=a+1;
	/* int b = 4;
	int c = 3 */
	a=a-1; */ 
}
