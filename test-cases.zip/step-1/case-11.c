int main()
{
 int a = 1, b=0;

 if(a >= 1 && a <= 10)
   	b++;

 else
       {  b--;
        /* }
}
