// primeiro programa
int main () {
  int k = 3;
  int p = 2 * k;
  return p;
}
