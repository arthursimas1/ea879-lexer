// Exemplo 2:

int main () {
    int i = 1;
    char s[] = "xpto";
    print("este é um teste:", s);
    print(i);
    print();
    return 0;
}
