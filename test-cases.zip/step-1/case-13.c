int v[5] = { 1, 3, 5, 7, 9};
assert v[3] == 7;
