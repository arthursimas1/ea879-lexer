// Exemplo 1:

int main () {
    int v[] = {1, 2, 3, 4, 5};
    int k = 3;
    int p = v[k];
    assert p == 4;
    return 0;
}
