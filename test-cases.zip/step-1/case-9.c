int main () {
    int i = 1;
    char s = 64;
    print(s + 32);
    print();
    return(0);
}
@