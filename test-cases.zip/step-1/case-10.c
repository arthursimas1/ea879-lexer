// single-line comment
// single // line // coment //
// /* /* */ *//

// reserved keywords
assert
break
char
else
for
if
int
print
read
return
void
while

// identifiers
foo_
_ bar239_foo

// int const
2
-3

// operators
+
-
*
/
%
<=
<
>=
>
==
!=
||
&&
!

// assignment
=

// delimiters
(
)
[
]
{
}
,
;

// edge cases
9898abcde
+-*/%<=<>=>||==!!=&&
