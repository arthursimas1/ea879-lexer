// Illegal character '$' at 5:5
int main()
{
  int x;
  x$ = 5;
}
