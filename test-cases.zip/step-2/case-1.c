/* comentário em bloco */
int j = 3; // atribuição no escopo global
int main () {
  int i = j;
  int k = 3;
  int p = 2 * j;
  assert(p == 2 * i);
}
