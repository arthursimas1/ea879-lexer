/* Exemplo 5: */

int MAX = 4;

int main() {
    int var[] = {10, 20, 40, 80};
    int aux;
    aux = var[0];
    for(int i = 0; i < MAX; i = i+1) {
        assert(var[i] == aux);
        aux = aux * 2;
    }
    return 0;
}
'aaaa
